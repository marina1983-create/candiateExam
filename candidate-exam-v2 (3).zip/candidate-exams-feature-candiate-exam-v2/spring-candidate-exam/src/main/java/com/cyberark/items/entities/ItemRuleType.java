package com.cyberark.items.entities;

public enum ItemRuleType {
    FIXED_VALUE,
    GAINS_VALUE_WITH_AGE,
    LOSES_CONSTANT_VALUE_WITH_AGE,
    LOSES_CONSTANT_PERCENT_WITH_AGE
}
